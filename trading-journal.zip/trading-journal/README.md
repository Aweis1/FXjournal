# Trading Journal

A single-file, dark-themed trading journal dashboard. No build step, no framework — just one `index.html`.

## Tabs
Sim Lab · Daily Brief · Overview · Timeline · Heatmap · By Day · Breakdown · Patterns · Mantra · Trade Log

## Important: how data is stored
This version saves your trades using the browser's `localStorage`, **not** a server or database.

- Data persists on **this device, in this browser** between visits.
- Data does **not** sync across devices or browsers.
- Clearing your browser data/cache will delete your trades.
- Private/incognito windows will not persist data after closing.

If you want true cross-device sync, you'd need to add a real backend (e.g. Supabase, Firebase, or a small API) — happy to help wire that up if you want it later.

## Deploy on Vercel
1. Push this folder to a GitHub repo.
2. Go to [vercel.com/new](https://vercel.com/new), import the repo.
3. No build settings needed — it's detected as a static site. Click Deploy.

## Deploy on GitHub Pages
1. Push this folder to a GitHub repo.
2. Repo Settings → Pages → Deploy from branch → select `main` and `/ (root)`.
3. Your site will be live at `https://<username>.github.io/<repo>/`.

## Run locally
Just open `index.html` directly in a browser, or serve it:
```bash
npx serve .
```
